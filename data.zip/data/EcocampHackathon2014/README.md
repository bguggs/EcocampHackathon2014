EcocampHackathon2014
====================
