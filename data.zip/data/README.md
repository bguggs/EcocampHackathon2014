# Streets Department EcoCamp Data
========================

Envirionmental data released by the Philadelphia Streets Department for [EcoCamp](http://phillyecocamp.org)

##Including:
###Code Violation Notices
Includes SWEEP violations, dumpster violations, litter violations, and more.

###Big Belly Waste Receptacle Locations & Usage
Includes locations and usage of the 1,000 big belly rubbish and recycling cans throughout the city.

###Litter Index
Results of an annual survey conducted to track approximate levels of litter throughout the city.

###RecycleBank Participation
A list of residents participating in the RecycleBank program as of March 2011

###Recycling Diversion Rates
Recycling rates by sanitation district from 2011 through 2014

##Credits
Streets Department

730 Municipal Services Building, 
1401 John F. Kennedy Boulevard, 
Philadelphia, PA 19102
